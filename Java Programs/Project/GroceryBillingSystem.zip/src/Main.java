import java.util.Scanner;

/**
 * Entry point of the Grocery Billing System
 */
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Inventory inventory = new Inventory();

        while (true) {
            System.out.println("\n===== Grocery Billing Menu =====");
            System.out.println("1. Add Product");
            System.out.println("2. Remove Product");
            System.out.println("3. View Inventory");
            System.out.println("4. Create Bill");
            System.out.println("5. Exit");
            System.out.print("Choose an option: ");
            int choice = sc.nextInt();

            if (choice == 1) {
                System.out.print("Enter ID, Name, Price, Quantity: ");
                int id = sc.nextInt();
                String name = sc.next();
                double price = sc.nextDouble();
                int quantity = sc.nextInt();
                inventory.addProduct(id, name, price, quantity);
            } else if (choice == 2) {
                System.out.print("Enter Product ID to remove: ");
                int id = sc.nextInt();
                inventory.removeProduct(id);
            } else if (choice == 3) {
                inventory.displayInventory();
            } else if (choice == 4) {
                Bill bill = new Bill();
                while (true) {
                    System.out.print("Enter Product ID to buy (0 to finish): ");
                    int id = sc.nextInt();
                    if (id == 0) break;
                    System.out.print("Enter quantity: ");
                    int qty = sc.nextInt();
                    Product product = inventory.findProductById(id);
                    if (product != null) {
                        bill.addProduct(product, qty);
                    } else {
                        System.out.println("Product not found.");
                    }
                }
                bill.generateBill(inventory);
            } else if (choice == 5) {
                System.out.println("Exiting...");
                break;
            } else {
                System.out.println("Invalid option.");
            }
        }

        sc.close();
    }
}
